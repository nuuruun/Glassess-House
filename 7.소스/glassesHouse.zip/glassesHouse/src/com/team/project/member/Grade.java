package com.team.project.member;

public enum Grade {
	
	ADMIN,
	STANDARD;
}
